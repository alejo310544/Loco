package com.doceestereo.streamer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

/** Keeps the app in a declared mediaProjection foreground-service state while capture runs. */
public class ProjectionForegroundService extends Service {
    public static final String ACTION_READY = "com.doceestereo.streamer.PROJECTION_SERVICE_READY";
    private static final String CHANNEL_ID = "stream1_projection";
    private static final int NOTIFICATION_ID = 1201;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Stream1 activo")
                .setContentText("Preparando captura de audio para la transmisión")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        sendBroadcast(new Intent(ACTION_READY).setPackage(getPackageName()));
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Stream1 transmisión", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Notificación necesaria durante la captura y transmisión de audio");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_NOT_STICKY; }
    @Override public IBinder onBind(Intent intent) { return null; }
}
