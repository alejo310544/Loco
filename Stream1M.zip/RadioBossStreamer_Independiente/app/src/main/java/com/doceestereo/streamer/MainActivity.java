package com.doceestereo.streamer;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int BG=0xff0a1020, CARD=0xff151f33, MUTED=0xff9cabc4, TEAL=0xff4de0c1, BLUE=0xff3478f6;
    private static final int REQUEST_CAPTURE=78;
    private static final int REQUEST_AUDIO_PERMISSION=79;
    private EditText host, port, password;
    private Spinner sourceSpinner;
    private TextView status;
    private final ArrayList<SourceApp> sources=new ArrayList<>();
    private RadioBossAudioStreamer engine;
    private String pendingHost, pendingPassword, pendingPackage;
    private int pendingPort, pendingUid=-1;
    private int pendingProjectionResultCode;
    private Intent pendingProjectionData;
    private boolean projectionReceiverRegistered;
    private final BroadcastReceiver projectionReadyReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { startProjectionAfterServiceReady(); }
    };
    private static class SourceApp {
        String label, packageName; int uid;
        SourceApp(String l,String p,int u){label=l;packageName=p;uid=u;}
        @Override public String toString(){return label;}
    }

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        buildUi();loadSources();
        IntentFilter filter = new IntentFilter(ProjectionForegroundService.ACTION_READY);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(projectionReadyReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(projectionReadyReceiver, filter);
        projectionReceiverRegistered = true;
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(dp(8),dp(6),dp(8),dp(6));return t;}
    private Button button(String s,int color){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setAllCaps(false);b.setMinHeight(dp(48));b.setBackground(round(color,14));return b;}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout card(){LinearLayout c=vertical();c.setPadding(dp(15),dp(14),dp(15),dp(16));c.setBackground(round(CARD,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(8),0,dp(8));c.setLayoutParams(p);return c;}
    private EditText field(String hint, boolean secret){EditText e=new EditText(this);e.setSingleLine(true);e.setTextColor(Color.WHITE);e.setHintTextColor(MUTED);e.setHint(hint);e.setPadding(dp(12),dp(9),dp(12),dp(9));e.setBackground(round(0xff202d43,12));if(secret)e.setInputType(129);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(50));p.setMargins(0,dp(5),0,dp(5));e.setLayoutParams(p);return e;}

    private void buildUi(){
        LinearLayout shell=vertical();shell.setPadding(dp(16),dp(12),dp(16),dp(12));shell.setBackgroundColor(BG);setContentView(shell);
        TextView eyebrow=text("12 ESTÉREO 101.3 FM  ·  TRANSMISOR",11,TEAL);eyebrow.setTypeface(null,Typeface.BOLD);shell.addView(eyebrow);
        TextView title=text("RadioBOSS Streamer",26,Color.WHITE);title.setTypeface(null,Typeface.BOLD);shell.addView(title);
        TextView intro=text("Envía a SHOUTcast 1 únicamente el audio capturable de la aplicación seleccionada. No transmite otras apps.",13,MUTED);shell.addView(intro);
        ScrollView scroll=new ScrollView(this);LinearLayout content=vertical();scroll.addView(content);shell.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout sourceCard=card();sourceCard.addView(text("1. FUENTE DE AUDIO",16,Color.WHITE));sourceCard.addView(text("Selecciona RadioBOSS Móvil instalado en este teléfono.",12,MUTED));sourceSpinner=new Spinner(this);sourceSpinner.setPadding(dp(8),dp(7),dp(8),dp(7));sourceSpinner.setBackground(round(0xff202d43,12));sourceCard.addView(sourceSpinner,new LinearLayout.LayoutParams(-1,dp(52)));content.addView(sourceCard);
        LinearLayout server=card();server.addView(text("2. SERVIDOR SHOUTcast 1",16,Color.WHITE));host=field("Dirección del servidor (sin http://)",false);host.setText(getPreferences(0).getString("host",""));server.addView(host);port=field("Puerto de fuente",false);port.setInputType(2);port.setText(getPreferences(0).getString("port","8000"));server.addView(port);password=field("Contraseña SOURCE",true);server.addView(password);password.setText(getPreferences(0).getString("password",""));server.addView(text("Formato de salida: MP3 mono, 22.05 kHz, 64 kbps.",11,MUTED));content.addView(server);
        LinearLayout actions=card();Button start=button("▶  AUTORIZAR AUDIO Y TRANSMITIR",0xff087d68);Button stop=button("■  DETENER TRANSMISIÓN",0xff8d3345);actions.addView(start);LinearLayout.LayoutParams gap=new LinearLayout.LayoutParams(-1,-2);gap.topMargin=dp(8);actions.addView(stop,gap);status=text("Estado: desconectado",13,TEAL);status.setGravity(Gravity.CENTER_VERTICAL);status.setPadding(dp(8),dp(12),dp(8),dp(4));actions.addView(status);content.addView(actions);
        TextView note=text("Nota: Android mostrará una autorización del sistema. RadioBOSS debe permitir la captura de audio; si la bloquea, el streamer no podrá recibirlo. Mantén RadioBOSS reproduciendo durante la prueba.",11,MUTED);content.addView(note);
        start.setOnClickListener(v->begin());stop.setOnClickListener(v->{if(engine!=null)engine.stop();stopProjectionService();setStatus("Deteniendo transmisión…");});
    }

    private void loadSources(){
        sources.clear();PackageManager pm=getPackageManager();
        try {
            ApplicationInfo ai=pm.getApplicationInfo("com.doceestereo.radioboss12",0);
            sources.add(new SourceApp(pm.getApplicationLabel(ai).toString()+" · RadioBOSS Móvil",ai.packageName,ai.uid));
        } catch(Exception ignored) {}
        try {
            List<PackageInfo> installed=pm.getInstalledPackages(0);
            for(PackageInfo pi:installed){if(pi.applicationInfo==null)continue;String pkg=pi.packageName;if(pkg.equals(getPackageName())||pkg.equals("com.doceestereo.radioboss12"))continue;String label=pm.getApplicationLabel(pi.applicationInfo).toString();String low=(label+" "+pkg).toLowerCase();if(low.contains("radioboss")||low.contains("radio boss")){sources.add(new SourceApp(label+" · "+pkg,pkg,pi.applicationInfo.uid));}}
        } catch(Exception ignored) {}
        if(sources.isEmpty())sources.add(new SourceApp("RadioBOSS Móvil no detectado", "com.doceestereo.radioboss12", -1));
        ArrayAdapter<SourceApp> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,sources);adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);sourceSpinner.setAdapter(adapter);
    }

    private void begin(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO},REQUEST_AUDIO_PERMISSION);return;}
        if(Build.VERSION.SDK_INT<29){setStatus("Se necesita Android 10 o superior para capturar audio interno.");return;}
        if(sources.isEmpty()||sourceSpinner.getSelectedItemPosition()<0){setStatus("No hay una fuente seleccionada.");return;}
        SourceApp src=sources.get(sourceSpinner.getSelectedItemPosition());
        if(src.uid<0){setStatus("No se encontró RadioBOSS. Instala primero RadioBOSS Móvil.");return;}
        String h=host.getText().toString().trim(), ps=password.getText().toString(), po=port.getText().toString().trim();
        int p;try{p=Integer.parseInt(po);}catch(Exception e){p=0;}
        if(h.isEmpty()||ps.isEmpty()||p<1||p>65535){Toast.makeText(this,"Completa dirección, puerto y contraseña SOURCE.",Toast.LENGTH_LONG).show();return;}
        pendingHost=h;pendingPort=p;pendingPassword=ps;pendingPackage=src.packageName;pendingUid=src.uid;
        getPreferences(0).edit().putString("host",h).putString("port",po).putString("password",ps).apply();
        MediaProjectionManager mgr=(MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mgr.createScreenCaptureIntent(),REQUEST_CAPTURE);
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==REQUEST_AUDIO_PERMISSION){if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED)begin();else setStatus("Permiso de captura de audio denegado.");}}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=REQUEST_CAPTURE)return;
        if(resultCode!=RESULT_OK||data==null){setStatus("Permiso de captura cancelado.");return;}
        pendingProjectionResultCode=resultCode;
        pendingProjectionData=data;
        try {
            Intent serviceIntent = new Intent(this, ProjectionForegroundService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent); else startService(serviceIntent);
            setStatus("Preparando servicio de captura…");
        } catch(Exception e) { setStatus("No se pudo iniciar el servicio: "+e.getMessage()); }
    }

    private void startProjectionAfterServiceReady() {
        if (pendingProjectionData == null) return;
        try {
            MediaProjectionManager mgr=(MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            MediaProjection projection=mgr.getMediaProjection(pendingProjectionResultCode,pendingProjectionData);
            pendingProjectionData=null;
            if(engine!=null)engine.stop();
            engine=new RadioBossAudioStreamer();
            engine.start(pendingHost,pendingPort,pendingPassword,pendingPackage,pendingUid,projection,msg->runOnUiThread(()->setStatus(msg)));
            setStatus("Preparando conexión y captura de RadioBOSS…");
        } catch(Exception e) { pendingProjectionData=null; stopProjectionService(); setStatus("No se pudo iniciar: "+e.getMessage()); }
    }

    private void stopProjectionService() {
        try { stopService(new Intent(this, ProjectionForegroundService.class)); } catch (Exception ignored) {}
    }

    private void setStatus(String s){if(status!=null)status.setText("Estado: "+s);}
    @Override protected void onDestroy(){if(engine!=null)engine.stop();stopProjectionService();if(projectionReceiverRegistered){try{unregisterReceiver(projectionReadyReceiver);}catch(Exception ignored){}}super.onDestroy();}
}
