package com.doceestereo.streamer;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.projection.MediaProjection;
import android.os.Handler;
import android.os.Looper;
import com.naman14.androidlame.AndroidLame;
import com.naman14.androidlame.LameBuilder;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;

/** Captures only the selected app UID, encodes it to MP3 and sends it to a SHOUTcast v1 source. */
final class RadioBossAudioStreamer {
    interface Listener { void onStatus(String message); }
    private static final int RATE = 22050;
    private static final int CHUNK = 1024;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private volatile Socket socket;
    private volatile AudioRecord recorder;
    private volatile AndroidLame lame;
    private volatile MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private Thread worker;

    boolean isRunning() { return running.get(); }

    synchronized void start(String host, int port, String password, String sourcePackage,
                             int sourceUid, MediaProjection mediaProjection, Listener listener) {
        if (running.get()) return;
        projection = mediaProjection;
        running.set(true);
        worker = new Thread(() -> streamLoop(host, port, password, sourcePackage, sourceUid, listener), "RadioBoss-Audio-Stream");
        worker.start();
    }

    private void status(Listener l, String s) { if (l != null) l.onStatus(s); }

    private void streamLoop(String rawHost, int port, String password, String sourcePackage,
                            int sourceUid, Listener listener) {
        try {
            String host = rawHost.trim().replaceFirst("^https?://", "").replaceAll("/.*$", "");
            if (host.isEmpty() || port < 1 || port > 65535 || password == null || password.isEmpty())
                throw new IllegalArgumentException("Completa dirección, puerto y contraseña de fuente.");
            if (sourceUid < 0) throw new IllegalArgumentException("No se encontró el UID de la aplicación seleccionada.");
            if (projection == null) throw new IllegalStateException("Android no autorizó la captura de audio.");

            status(listener, "Conectando con SHOUTcast 1…");
            socket = new Socket();
            socket.connect(new InetSocketAddress(host, port), 10000);
            socket.setSoTimeout(10000);
            InputStream in = new BufferedInputStream(socket.getInputStream());
            OutputStream out = new BufferedOutputStream(socket.getOutputStream());
            out.write((password + "\r\n").getBytes(StandardCharsets.ISO_8859_1));
            out.flush();
            String response = readLine(in, 1024);
            if (response == null || !(response.startsWith("OK") || response.startsWith("ICY 200")))
                throw new IllegalStateException("El servidor rechazó la fuente: " + (response == null ? "sin respuesta" : response));
            socket.setSoTimeout(0);

            int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) throw new IllegalStateException("Android no permite iniciar la captura de audio.");
            int bufferBytes = Math.max(min * 2, CHUNK * 2 * 4);
            projectionCallback = new MediaProjection.Callback() {
                @Override public void onStop() {
                    running.set(false);
                    try { if (recorder != null && recorder.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) recorder.stop(); } catch (Exception ignored) {}
                }
            };
            projection.registerCallback(projectionCallback, new Handler(Looper.getMainLooper()));
            AudioFormat format = new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build();
            AudioPlaybackCaptureConfiguration config = new AudioPlaybackCaptureConfiguration.Builder(projection)
                    .addMatchingUid(sourceUid)
                    .addMatchingUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .build();
            recorder = new AudioRecord.Builder().setAudioFormat(format).setBufferSizeInBytes(bufferBytes)
                    .setAudioPlaybackCaptureConfig(config).build();
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED)
                throw new IllegalStateException("No se pudo capturar RadioBOSS. Comprueba que la app permite capturar su audio.");
            lame = new LameBuilder().setInSampleRate(RATE).setOutSampleRate(RATE)
                    .setOutChannels(1).setOutBitrate(64).build();
            short[] pcm = new short[CHUNK];
            byte[] mp3 = new byte[8192];
            recorder.startRecording();
            status(listener, "Transmitiendo solo audio de " + sourcePackage + " · MP3 64 kbps");
            while (running.get()) {
                int n = recorder.read(pcm, 0, pcm.length, AudioRecord.READ_BLOCKING);
                if (n > 0) {
                    int bytes = lame.encode(pcm, pcm, n, mp3);
                    if (bytes > 0) { out.write(mp3, 0, bytes); out.flush(); }
                } else if (n < 0) {
                    throw new IllegalStateException("Error leyendo audio interno: " + n);
                }
            }
            int flushed = lame.flush(mp3);
            if (flushed > 0) { out.write(mp3, 0, flushed); out.flush(); }
        } catch (Exception e) {
            if (running.get()) status(listener, "Error de emisión: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
        } finally {
            running.set(false);
            try { if (recorder != null) { if (recorder.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) recorder.stop(); recorder.release(); } } catch (Exception ignored) {}
            recorder = null;
            try { if (lame != null) lame.close(); } catch (Exception ignored) {}
            lame = null;
            try { if (socket != null) socket.close(); } catch (Exception ignored) {}
            socket = null;
            if (projection != null) {
                try { if (projectionCallback != null) projection.unregisterCallback(projectionCallback); } catch (Exception ignored) {}
                try { projection.stop(); } catch (Exception ignored) {}
            }
            projection = null;
            status(listener, "Emisión detenida");
        }
    }

    private static String readLine(InputStream in, int limit) throws Exception {
        StringBuilder b = new StringBuilder(); int c;
        while (b.length() < limit && (c = in.read()) != -1) { if (c == '\n') break; if (c != '\r') b.append((char)c); }
        return b.length() == 0 ? null : b.toString();
    }

    synchronized void stop() {
        running.set(false);
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        try { if (recorder != null && recorder.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) recorder.stop(); } catch (Exception ignored) {}
        try { if (projection != null) projection.stop(); } catch (Exception ignored) {}
    }
}
