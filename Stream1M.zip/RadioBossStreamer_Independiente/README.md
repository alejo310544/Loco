# RadioBOSS Streamer — proyecto Android independiente

Aplicación separada de RadioBOSS Móvil para transmitir a un servidor SHOUTcast 1 el audio interno capturable de una sola aplicación elegida por UID. Incluye codificación MP3 mediante TAndroidLame.

## Requisitos
- Android 10 (API 29) o superior.
- RadioBOSS Móvil instalado y reproduciendo.
- Servidor SHOUTcast v1 con puerto de fuente y contraseña SOURCE.
- Conexión a internet.

## Compilar con GitHub Actions
1. Sube el contenido de este ZIP a un repositorio nuevo.
2. Crea el archivo `.github/workflows/build-apk.yml` (se incluye abajo como ejemplo en el repositorio raíz).
3. Ejecuta **Actions → Compilar RadioBOSS Streamer → Run workflow**.
4. Descarga el artefacto `RadioBOSS-Streamer-APK`.

## Limitaciones importantes
- Android muestra una autorización del sistema para capturar reproducción.
- La app fuente debe permitir la captura de audio. El proyecto RadioBOSS Móvil actual no declara explícitamente `allowAudioPlaybackCapture="false"`, por lo que en Android 10+ normalmente se permite, pero hay que probarlo en el teléfono.
- La captura se limita al UID seleccionado y al uso de audio multimedia; no mezcla el micrófono ni captura otras aplicaciones.
- Esta versión mantiene la transmisión mientras la pantalla de la aplicación permanece activa. Para una emisión larga sin mantener la pantalla abierta, falta integrar un servicio en primer plano dedicado y probar su comportamiento en el teléfono.
- El protocolo de autenticación puede variar según la configuración concreta del proveedor SHOUTcast. La compilación del código y la conexión real deben probarse con el servidor del usuario.

### Corrección de MediaProjection (Android 14+)

La app declara `FOREGROUND_SERVICE_MEDIA_PROJECTION` y el servicio `ProjectionForegroundService` con tipo `mediaProjection`. Tras autorizar la captura, inicia primero el servicio en primer plano y después crea `MediaProjection`, para evitar el error de tipo de servicio requerido.
